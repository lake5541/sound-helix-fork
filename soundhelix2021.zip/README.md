# soundhelix2021
better xml for the famous project i worked on
The harmonics could be tighter. I am working 
on that but the overall is nailed. Its fun.
run sh run.sh to start.
