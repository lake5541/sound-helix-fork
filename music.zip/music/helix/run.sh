#!/bin/bash

java -jar -Xms1g -Xmx1g -Xss200m SoundHelix.jar examples/mixtape3.xml
