#!/bin/bash

java -jar  SoundHelix.jar examples/mixtape3.xml
